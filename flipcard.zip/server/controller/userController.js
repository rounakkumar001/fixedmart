import { response } from "express";
import User from "../database/userSchema.js";

export const authenticateSignup = async(req, res) =>{
    try{   
        
        const exist = await User.findOne({username : req.body.username});
        console.log("exist data ", exist);

        if(exist){
            return (res.status(401).json({message : 'username already exist.'}));
        }
        
        const user = req.body;
        const newUser = new User(user)
        await newUser.save();
        
        res.status(200).json({message : user});
    }   
    catch(error){
        // console.log('error while authenticateSignup user', error);
        res.status(500).json({message : error.message});
    }
}


export const authenticateLogin = async(req, res) => {
    try{
        const username = req.body.username;
        const password = req.body.password;

        const user = await User.findOne({username: username, password : password});

        if(user){
            return res.status(200).json({data : user});
        }
        else{
            return res.status(401).json(`Invalid login`);
        }

    }
    catch(e){
        res.status(500).json("Error", e.message);
        
    }
}