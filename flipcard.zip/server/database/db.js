import mongoose from 'mongoose';

export const Connection = async(user, password) => {
    const URL = `mongodb+srv://${user}:${password}@flipkart.fw45ado.mongodb.net/?retryWrites=true&w=majority`;
    try{
        await mongoose.connect(URL); 
        console.log("Database Connected Successfully.");
    }
    catch(error){
        console.log("Error while connecting with the database", error.message);
    }


}


export default Connection;